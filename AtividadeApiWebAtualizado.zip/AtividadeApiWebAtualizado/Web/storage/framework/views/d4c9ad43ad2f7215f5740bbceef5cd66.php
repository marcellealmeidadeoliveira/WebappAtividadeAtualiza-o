
 
<?php $__env->startSection('content'); ?>
    <h1
    style="color:#880808; font-weight:bold; font-size:30px; "
    >Editar informações</h1>
    <form method="POST" action="<?php echo e(route('rota.update', $registro['id'])); ?>">
        <?php echo csrf_field(); ?>
        <div style=" border-radius: 20px; width: 50%; margin:auto; margin-top:90px">

            <label style="color:#880808; font-weight:bold; font-size:30px;">
                
            Nome do conto</label>
            <input type="text" name="nome" class="form-control" value="<?php echo e($registro['nome']); ?>" required>



            <label style="color:#880808; font-weight:bold; font-size:30px;">Nome criador</label>
            <input type="text" name="nomeCriador" class="form-control" value="<?php echo e($registro['nomeCriador']); ?>" required>


        
            <label style="color:#880808; font-weight:bold; font-size:30px;">Idioma</label>
            <input type="text" name="idioma" class="form-control" value="<?php echo e($registro['idioma']); ?>" required>
   

        
            <label style="color:#880808; font-weight:bold; font-size:30px;">Tipo</label>
            <input type="text" name="tipo" class="form-control" value="<?php echo e($registro['tipo']); ?>" required>
    

        
            <label style="color:#880808; font-weight:bold; font-size:30px;">Sinopsia</label>
            <input type="text" name="sinopsia" class="form-control" value="<?php echo e($registro['sinopsia']); ?>" required>
        </div>
<div style="aling-items: center; display: flex; justify-content: center; margin-top: 20px;">
        <button type="submit" class="btn btn-primary">Alterar</button>
        </div>
        <div style="aling-items: center; display: flex; justify-content: center; margin-top: 20px;">
        <a href="<?php echo e(route('rota.index')); ?>" class="btn btn-secondary">Cancelar</a>
</div>
    </form>

<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marcelle.aoliveira\Desktop\API-laravel\analogWeb\resources\views/abas/editar.blade.php ENDPATH**/ ?>