
<?php $__env->startSection('content'); ?>

   <div style='margin-left: 20px; margin-right: 20px;'>
    <h1 style="color:#880808; text-align:center; margin-top:10px; font-weight:bold
">
Tabela analog
   </h1>
 <a href="<?php echo e(route('rota.create')); ?>"
 class="btn btn-sucess mb-3">



<h1 style="color:#880808; text-align:center; margin-top:10px; font-weight:bold; margin-top:-50px
" >
    Lista de Contos AudioVisuais de Terror
</h1>

</a> <?php if(count($registro)): ?>

 <div>
    <table class="table table-hover table-dark">
        <thead>
        <tr>
        <th >Codigo</th>
            <th>Nome</th>
            <th>Episodios</th>
            <th>Quantidade de temporadas</th>
           <th>Duração</th>
            <th>Ano lançamento</th>
            <th>Ações</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $registro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <th><?php echo e($item['id']); ?></th>
        <td><?php echo e($item['nome2']); ?></td>
    <td><?php echo e($item['episodios']); ?></td>
    <td><?php echo e($item['quantasT']); ?></td>
        <td><?php echo e($item['duracao']); ?></td>
            <td><?php echo e($item['anoLancamento']); ?></td>
            <th>
              <a href="<?php echo e(route('rota.edit',$item['id'])); ?>" class="btn btn-warning btm-sm">Editar</a>

                    <a href="<?php echo e(route('rota.destroy',$item['id'])); ?>" class="btn btn-danger btm-sm" onclick="return confirm('Tem certeza?')">Excluir</a>      
</th>



</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<div style="align-items: center; display: flex; justify-content: center;">


<a href="<?php echo e(route('rota.create')); ?>" class="btn btn-success mt-3" >Cadastrar Novo Analog Horror</a>
<a href="<?php echo e(route('temporadas.index')); ?>" class="btn btn-success mt-3" >Cadastrar novos dados</a>
</div>


</div>
<?php else: ?><p>
    Não a nenhum registro cadastrado
</p>
<?php endif; ?>
<?php echo $__env->make('layout.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marcelle.aoliveira\Desktop\API-laravel\analogWeb\resources\views/temporadas/index.blade.php ENDPATH**/ ?>